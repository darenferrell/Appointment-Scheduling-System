package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Contacts;
import model.Customers;
import model.Users;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ResourceBundle;
public class AddAppointmentController implements Initializable {

    @FXML
    private AnchorPane addAppointmentScreen;

    @FXML
    private Label addAppointmentTitle;

    @FXML
    private Button cancelButton;

    @FXML
    private Label contactIDLabel;

    @FXML
    private ComboBox<Contacts> contactIDCombinationBox;

    @FXML
    private Label customerIDLabel;

    @FXML
    private ComboBox<?> customerIDCombinationBox;

    @FXML
    private Label descriptionLabel;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private Label endDateLabel;

    @FXML
    private DatePicker endDateCombinationBox;

    @FXML
    private Label endTimeLabel;

    @FXML
    private TextField endTimeTextField;

    @FXML
    private Label locationLabel;

    @FXML
    private TextField locationTextField;

    @FXML
    private Button saveButton;

    @FXML
    private Label startDateLabel;

    @FXML
    private DatePicker startDateCombinationBox;

    @FXML
    private Label startTimeLabel;

    @FXML
    private TextField startTimeTextField;

    @FXML
    private Label timeFormatInstruction;

    @FXML
    private Label titleLabel;

    @FXML
    private TextField titleTextField;

    @FXML
    private Label typeLabel;

    @FXML
    private TextField typeTextField;

    @FXML
    private Label userIDLabel;

    @FXML
    private ComboBox<?> userIDCombinationBox;

    public ComboBox<Contacts> contactsCombinationBox;

    public ComboBox<Customers> customersCombinationBox;

    public ComboBox<Users> usersCombinationBox;

    public DatePicker startDatePicker;

    public DatePicker endDatePicker;

    public ComboBox<LocalTime> startTimeCombinationBox;

    public ComboBox<LocalTime> endTimeCombinationBox;

    public int customerID;

    public int userID;

    public int contactID;

    public String title;

    public String description;

    public String location;

    public String type;

    public LocalDate startDate;

    public LocalDate endDate;

    public LocalTime startTime;

    public LocalTime endTime;

    public LocalDateTime startDateAndTime;

    public LocalDateTime endDateAndTime;
    
    Stage stage;

    Parent scene;

    public void saveButtonPressed(ActionEvent actionEvent) throws IOException {
        }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
