package controller;

import dao.*;
import helper.JDBC;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;
import model.Customers;
import model.Users;
import utilities.ChronologySetter;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Optional;
import java.util.ResourceBundle;

import static javax.swing.UIManager.getInt;

public class ModifyAppointmentController implements Initializable {

    @FXML
    public Label typeLabel;

    @FXML
    public Label modifyAppointmentScreenLabel;

    @FXML
    private Label appointmentIDLabel;

    @FXML
    private TextField appointmentIDTextField;

    @FXML
    private Button cancelButton;

    @FXML
    private Label contactIDLabel;

    @FXML
    private TextField contactIDTextField;

    @FXML
    private Label customerIDLabel;

    @FXML
    private TextField customerIDTextField;

    @FXML
    private Label descriptionLabel;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private Label endDateLabel;

    @FXML
    private DatePicker endDateSelectionBox;

    @FXML
    private Label endTimeLabel;

    @FXML
    private TextField endTimeTextField;

    @FXML
    private Label locationLabel;

    @FXML
    private TextField locationTextField;

    @FXML
    private AnchorPane modifyAppointmentScreen;

    @FXML
    private Label modifyAppointmentScreenTitle;

    @FXML
    private Button saveButton;

    @FXML
    private Label startDateLabel;

    @FXML
    private DatePicker startDateSelectionBox;

    @FXML
    private Label startTimeLabel;

    @FXML
    private TextField startTimeTextField;

    @FXML
    private Label timeFormatLabel;

    @FXML
    private Label titleLabel;

    @FXML
    private TextField titleTextField;

    @FXML
    private TextField typeTextField;

    @FXML
    private Label typeTitle;

    @FXML
    private Label userIDLabel;

    @FXML
    private TextField userIDTextField;

    Stage stage;

    Parent scene;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    @FXML
    void cancelButtonPressed(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Would you like to cancel and return to the main menu?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }




    public void divisionIDCombinationBoxSelected(ActionEvent actionEvent) {
    }

    public void StateProvinceCombinationBoxSelected(ActionEvent actionEvent) {
    }


    public void saveButtonPressed(ActionEvent actionEvent) {
    }
}