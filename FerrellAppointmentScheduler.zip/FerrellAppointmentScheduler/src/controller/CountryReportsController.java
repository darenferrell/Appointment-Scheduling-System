package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.EventObject;
import java.util.Optional;
import java.util.ResourceBundle;

public class CountryReportsController {

    public TableColumn customerIDColumn;

    public TableColumn nameColumn;

    public TableColumn addressColumn;

    public TableColumn postalCodeColumn;

    public TableColumn phoneColumn;

    public Label reportsTitle;

    public TableView countryReportsTable;

    public TableColumn totalCustomersLabel;

    public ComboBox countriesCombinationBox;
    public Button customersButton;
    public Button countriesReportsButton;
    public Button logoutButton;

    private Stage stage;

    private Parent scene;

    public Button cancelButton;

    public Button generateCountryReportsButton;

    @FXML
    private Button appointmentsButton;

    @FXML
    private TableColumn<?, ?> countryColumn;

    @FXML
    private EventObject actionEvent;

    @FXML
    void appointmentsButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/appointmentsMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void customersButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customersMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void logoutButtonPressed(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setContentText("Please confirm that you want to log out.");
        alert.showAndWait();
        Optional<ButtonType> result = alert.showAndWait();

        if ((result.isPresent() && result.get() == ButtonType.OK)) {
            System.exit(0);
        }
    }

    @FXML
    void cancelButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void countriesReportsButtonPressed(ActionEvent actionEvent) {

    }

    public void initialize(URL url, ResourceBundle resourceBundle) throws SQLException {

    }


    public void countriesCombinationBoxPressed(ActionEvent actionEvent) {
    }

}
