package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;

import java.io.IOException;
import java.net.URL;
import java.util.EventObject;
import java.util.Optional;
import java.util.ResourceBundle;

public class ContactReportsController implements Initializable {

    @FXML
    public Label totalAppointmentsLabel;

    @FXML
    public ComboBox contactsCombinationBox;

    private Stage stage;

    private Parent scene;

    @FXML
    public TableView<Appointments> contactReportsTable;

    @FXML
    private TableColumn<?, ?> appointmentIDColumn;

    @FXML
    private Button appointmentsButton;

    @FXML
    private TableView<?> appointmentsMainTableView;

    @FXML
    private Button cancelButton;

    @FXML
    private TableColumn<?, ?> contactNameColumn;

    @FXML
    private AnchorPane contactReportsScreen;

    @FXML
    private TableColumn<?, ?> customerIDColumn;

    @FXML
    private Button customersButton;

    @FXML
    private TableColumn<?, ?> descriptionColumn;

    @FXML
    private TableColumn<?, ?> endDateAndTimeColumn;

    @FXML
    private Button generateContactReportsButton;

    @FXML
    private TableColumn<?, ?> locationColumn;

    @FXML
    private Button logoutButton;

    @FXML
    private Label reportsTitle;

    @FXML
    private TableColumn<?, ?> startDateAndTimeColumn;

    @FXML
    private TableColumn<?, ?> titleColumn;

    @FXML
    private TableColumn<?, ?> typeColumn;

    @FXML
    private TableColumn<?, ?> userIDColumn;


    private EventObject actionEvent;

    public ComboBox<Contacts> contactsComboBox;

    @FXML
    void appointmentsButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/appointmentsMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void customersButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button)  event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customersMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void logoutButtonPressed(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setContentText("Please confirm that you want to log out.");
        alert.showAndWait();
        Optional<ButtonType> result = alert.showAndWait();
        if ((result.isPresent() && result.get() == ButtonType.OK)) {
            System.exit(0);
        }
    }

    @FXML
    void cancelButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void contactsReportButtonPressed(ActionEvent event) {

    }


    public void contactsCombinationBoxPressed(ActionEvent actionEvent) {
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
