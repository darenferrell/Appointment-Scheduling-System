package controller;

import dao.AppointmentsDAO;
import dao.AppointmentsDAOImpl;
import helper.JDBC;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.Optional;
import java.util.ResourceBundle;

public class AppointmentsMainController implements Initializable {

    @FXML
    public TableView<model.Appointments> appointmentsMainTableView;

    @FXML
    public TableColumn<?, ?> contactNameColumn;

    @FXML
    public Label userTimeZoneLabel;

    @FXML
    public Button modifyAppointmentButton;

    @FXML
    public Button addAppointmentButton;

    @FXML
    public Button deleteAppointmentButton;

    public TableColumn<Object, Object> startTimeColumn;

    public TableColumn<Object, Object> startDateColumn;

    public TableColumn<Object, Object> endTimeColumn;

    public TableColumn contactColumn;

    public TableColumn<Object, Object> endDateColumn;

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<?, ?> appointmentIDColumn;

    @FXML
    private AnchorPane appointmentsMainScreen;

    @FXML
    private Label appointmentsMainTitle;

    @FXML
    private TableColumn<?, ?> customerIDColumn;

    @FXML
    private Button customersButton;

    @FXML
    private Button deleteButton;

    @FXML
    private TableColumn<?, ?> descriptionColumn;

    @FXML
    private TableColumn<?, ?> endDateAndTimeColumn;

    @FXML
    private Button exitButton;

    @FXML
    private TableColumn<?, ?> locationColumn;

    @FXML
    private Button modifyButton;

    @FXML
    private Button reportsButton;

    @FXML
    private TableColumn<?, ?> startDateAndTimeColumn;

    @FXML
    private TableColumn<?, ?> titleColumn;

    @FXML
    private TableColumn<?, ?> typeColumn;

    @FXML
    private TableColumn<?, ?> userIDColumn;

    Stage stage;

    Parent scene;

    @FXML
    void addAppointmentButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/addAppointment.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    public void modifyAppointmentButtonPressed(ActionEvent event) throws IOException, SQLException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/modifyAppointment.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    @FXML
    void customersButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customersMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    @FXML
    void deleteAppointmentButtonPressed(ActionEvent event) {

    }

    @FXML
    void exitButtonPressed(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setContentText("Are you sure that you would like to log out?");
        Optional<ButtonType> result = alert.showAndWait();
        if ((result.isPresent() && result.get() == ButtonType.OK)) {
            System.exit(0);
        }
    }

    @FXML
    void reportsButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("Appointment Schedule (Main Menu): I am initialized!");

        userTimeZoneLabel.setText("Your Time Zone: " + String.valueOf(ZoneId.systemDefault()));

        appointmentIDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        contactColumn.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        startDateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        endDateColumn.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        startTimeColumn.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        endTimeColumn.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        customerIDColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        userIDColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));

        JDBC.openConnection();
        AppointmentsDAO appointmentDao = new AppointmentsDAOImpl();
        appointmentsMainTableView.setItems(appointmentDao.getAllAppointments());
    }
}






