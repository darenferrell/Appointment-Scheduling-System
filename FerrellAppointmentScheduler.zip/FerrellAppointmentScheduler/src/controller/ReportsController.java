package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.EventObject;
import java.util.Optional;
import java.util.ResourceBundle;

public class ReportsController implements Initializable {

    private Stage stage;

    private Parent scene;

    @FXML
    private Button appointmentsButton;

    @FXML
    private Button contactsButton;

    @FXML
    private Button countriesButton;

    @FXML
    private Button customersButton;

    @FXML
    private Button logoutButton;

    @FXML
    private Button monthlyReportsButton;

    @FXML
    private AnchorPane reportsScreen;

    @FXML
    private Label titleLabel;

    @FXML
    private EventObject actionEvent;

    @FXML
    private java.awt.event.ActionEvent event;

        @FXML
        void contactsButtonPressed(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/contactReports.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

        @FXML
        void countriesButtonPressed(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/countryReports.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

        @FXML
        void customersButtonPressed(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

        @FXML
        void logoutButtonPressed(ActionEvent event) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Logout");
            alert.setContentText("Please confirm that you want to log out.");
            alert.showAndWait();
            Optional<ButtonType> result = alert.showAndWait();
            if ((result.isPresent() && result.get() == ButtonType.OK)) {
                System.exit(0);
            }
        }

        @FXML
        void monthlyReportsButtonPressed(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/monthlyReports.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

    @FXML
    void appointmentsButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/appointmentsMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
    }







}
