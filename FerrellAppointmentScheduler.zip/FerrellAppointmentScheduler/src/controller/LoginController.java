package controller;

import dao.UsersDAO;
import dao.UsersDAOImpl;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;


public class LoginController implements Initializable {

    @FXML
    public TextField userNameTextField;

    @FXML
    public Label userNameLabel;

    @FXML
    public Button resetButton;

    @FXML
    private Button exitButton;

    @FXML
    private Button loginButton;

    @FXML
    private Label loginRequestLabel;

    @FXML
    private AnchorPane loginScreen;

    @FXML
    private Label passwordLabel;

    @FXML
    private TextField passwordTextField;

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label zoneIDLabel;

    @FXML
    private Stage stage;

    @FXML
    private Parent scene;

    ResourceBundle rb = ResourceBundle.getBundle("Languages/lang");

    public void loginButtonPressed(javafx.event.ActionEvent actionEvent) {
        try{
            String userName = userNameTextField.getText();
            String password = String.valueOf(passwordTextField.getText());
            LocalDateTime now = LocalDateTime.now();
            String fileName = "login_activity.txt";
            FileWriter fileWriter = new FileWriter(fileName, true);
            PrintWriter outputFile = new PrintWriter(fileWriter);
            UsersDAO UDAO = new UsersDAOImpl();
            System.out.println(UDAO.loginQuery(userName, password));
            if (UDAO.loginQuery(userName, password) == true){
                stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/appointmentsMain.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }
            else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Invalid Username and/or Password. Please try again!");
                alert.showAndWait();
                outputFile.println(userName + " Login was unsuccessful at " + now + " (" + ZoneId.systemDefault() + ")");
            }
            outputFile.close();
        }catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void resetButtonPressed(javafx.event.ActionEvent actionEvent) {
        userNameTextField.setText("");
        passwordTextField.setText("");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        zoneIDLabel.setText(String.valueOf(ZoneId.systemDefault()));
        try {
            if (Locale.getDefault().getLanguage().equals("fr")) {
                ResourceBundle rb = ResourceBundle.getBundle("languages/language_fr", Locale.getDefault());
                userNameLabel.setText(rb.getString("Username"));
                passwordLabel.setText(rb.getString("Password"));
                zoneIDLabel.setText(rb.getString("TimeZone"));
                resetButton.setText(rb.getString("Reset"));
                loginButton.setText(rb.getString("Login"));
            }
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void exitButtonPressed(javafx.event.ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setContentText("Are you sure that you would like to log out?");
        Optional<ButtonType> result = alert.showAndWait();
        if ((result.isPresent() && result.get() == ButtonType.OK)) {
            System.exit(0);
        }
    }


}