package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.EventObject;
import java.util.Optional;

public class MonthlyReportsController {

    @FXML
    public Button generateMonthlyReportsButton;

    @FXML
    public Label backToLabel;

    @FXML
    public Button cancelButton;

    @FXML
    public Label reportsTitle;

    @FXML
    private Stage stage;

    @FXML
    private Parent scene;

    @FXML
    private TableColumn<?, ?> appointmentTypeColumn;

    @FXML
    private Button appointmentsButton;

    @FXML
    private Button customersButton;

    @FXML
    private Button logoutButton;

    @FXML
    private TableColumn<?, ?> monthColumn;

    @FXML
    private TableView<?> monthlyReportsTable;

    @FXML
    private TableColumn<?, ?> totalNumberOfAppointmentsColumn2;

    @FXML
    private EventObject actionEvent;

    ActionEvent event;

    @FXML
    void appointmentsButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/AppointmentsMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void customersButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/CustomersMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void logoutButtonPressed(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setContentText("Please confirm that you want to log out");
        alert.showAndWait();
        Optional<ButtonType> result = alert.showAndWait();
        if ((result.isPresent() && result.get() == ButtonType.OK)) {
            System.exit(0);
        }
    }

    @FXML
    void cancelButtonPressed(ActionEvent event) throws IOException {
        stage = (Stage)((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reports.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void monthlyReportsButtonPressed(ActionEvent actionEvent) {
    }
}
