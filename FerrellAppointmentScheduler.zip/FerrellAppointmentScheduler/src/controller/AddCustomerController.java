package controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class AddCustomerController implements Initializable {

    public Label postalCodeLabel;

    public ChoiceBox<model.Divisions> divisionCombinationBox;

    public ComboBox<model.Countries> countryCombinationBox;

    public ComboBox<model.Divisions> divisionIDCombinationBox;

    public ComboBox StateProvinceCombinationBox;

    public Label divisionLabel;

    public Label addressLabel;

    public Label phoneNumberLabel;

    public Label stateProvinceLabel;
    
    public Button saveButton;
    
    public Label customerNameLabel;

    public Label addCustomerScreenLabel;

    public Label countryIDLabel;

    public Label divisionIDLabel;

    public TextField countryIDTextField;

    public TextField divisionIDTextField;

    public TextField stateProvinceTextField;

    @FXML
    private AnchorPane addCustomerScreen;

    @FXML
    private TextField addressTextField;

    @FXML
    private Button cancelButton;

    @FXML
    private ChoiceBox<?> countrySelectionBox;

    @FXML
    private TextField customerNameTextField;

    @FXML
    private TextField phoneNumberTextField;

    @FXML
    private TextField postalCodeTextField;

    String customerName;

    String address;

    String postalCode;

    String phone;

    int divisionID;

    Stage stage;

    Parent scene;

    @FXML
    void cancelButtonPressed(ActionEvent event) throws IOException {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setContentText("Would you like to cancel and return to the main menu?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/customersMain.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }
        }

    @FXML
    void saveButtonPressed(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void selectCountryButtonPressed(ActionEvent actionEvent) {
    }
}