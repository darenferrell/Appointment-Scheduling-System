package utilities;

//public class DivisionListManager {
//
//    public static ObservableList<Divisions> getFilteredDivisions(int countryID){
////        DivisionsDAO divisionsDAO = new DivisionsDAOImpl();
////        return divisionsDAO.getDivisionBasedOnCountry(countryID);
////    }
//}
