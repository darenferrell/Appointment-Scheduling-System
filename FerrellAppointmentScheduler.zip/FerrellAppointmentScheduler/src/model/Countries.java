package model;

public class Countries {
    private int countryID;
    private String countryName;
    private int countryMonthTotal;
    private String specificCountryMonth;


    public Countries(String specificCountryMonth, int totalCountryMonths) {
        this.specificCountryMonth = specificCountryMonth;
        this.countryMonthTotal = totalCountryMonths;
    }


    public int getCountryID() {
        return countryID;
    }

    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {

        this.countryName = countryName;
    }

    @Override
    public String toString() {
        return (countryName);
    }
}



