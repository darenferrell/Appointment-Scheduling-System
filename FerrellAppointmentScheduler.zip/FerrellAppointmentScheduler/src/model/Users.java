package model;

public class Users {
    private int userID;
    private String userName;
    private String password;

    public Users(String userName, String password) {
        this.userID = this.userID;
        this.userName = userName;
        this.password = password;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String username) {
        this.userName = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return ("[" + Integer.toString(userID) + "]" + userName);
    }
}
