package model;

public class Customers {

    private int customerID;
    private int divisionID;
    private int countryID;
    private String customerName;
    private String address;
    private String zipCode;
    private String phone;
    private String countryName;
    private String divisionName;

    public Customers(int customerID, int divisionID, int countryID, String customerName, String address,
                     String zipCode, String phone, String countryName, String divisionName) {

        this.customerID = customerID;
        this.divisionID = divisionID;
        this.countryID = countryID;
        this.customerName = customerName;
        this.address = address;
        this.zipCode = zipCode;
        this.phone = phone;
        this.countryName = countryName;
        this.divisionName = divisionName;
    }

    public Customers(int customerID) {
    }

    public Customers(String customerName) {
    }

    public Customers(int customerID, String customerName, String address, String postalCode, int phone, int divisionID) {
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getDivisionID() {
        return divisionID;
    }

    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    public int getCountryID() {
        return countryID;
    }

    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    @Override
    public String toString() {
        return ("[" + Integer.toString(customerID) + "] " + customerName);
    }
}
