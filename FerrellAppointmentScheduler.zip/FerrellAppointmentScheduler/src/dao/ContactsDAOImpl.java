package dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contacts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static helper.JDBC.connection;

public class ContactsDAOImpl implements ContactsDAO {

    ObservableList<Contacts> allContacts = FXCollections.observableArrayList();

    @Override
    public ObservableList<Contacts> getAllContacts() {
        try {
            String sql = "SELECT * FROM contacts";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();

            while (result.next()) {
                int contactID = result.getInt("Contact ID");
                String contactName = result.getString("Contact Name");

                Contacts contact = new Contacts(contactID, contactName);
                allContacts.add(contact);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        return allContacts;
    }


    @Override
    public Contacts getContact(int contactID) {
        try {
            String sql = "SELECT FROM contacts where contact_ID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, contactID);
            ResultSet result = ps.executeQuery();
            Contacts contactResult = null;

            if (result.next()) {
                contactID = result.getInt("Contact_ID");
                String contactName = result.getString("Contact_Name");
                contactResult = new Contacts(contactID, contactName);
            }
            return contactResult;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }


    @Override
    public int modifyContact(int contactID, String currentContactName, String newContactName) {

        int affectedRows = 0;
        try {
            String sql = "UPDATE contacts set Contact_Name=? WHERE Contact_Name=? AND Contact_ID=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, newContactName);
            ps.setString(2, currentContactName);
            ps.setInt(3, contactID);
            affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println(currentContactName + "modification was successful!");
                System.out.println("New Contact name: " + newContactName);

            } else {
                System.out.println(currentContactName + " name modification has failed.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }

    @Override
    public int deleteContact(int contactID) {
        int affectedRows = 0;

        try {
            String sql = "DELETE FROM contacts WHERE Contact_ID=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, contactID);
            affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Contact " + contactID + "was successfully deleted.");

            } else {
                System.out.println("Contact " + contactID + "has not been deleted.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }


    @Override
    public int addContact(String contactName) {
        int affectedRows = 0;
        try {
            String sql = "INSERT INTO contacts (Contact_Name) WHERE Contact_ID=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, contactName);
            affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Contact " + contactName + "was added successfully.");

            } else {
                System.out.println("Contact " + contactName + "has not been added.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }
}



