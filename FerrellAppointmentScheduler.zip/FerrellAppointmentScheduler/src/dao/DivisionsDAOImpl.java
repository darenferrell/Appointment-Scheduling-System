package dao;

import javafx.collections.ObservableList;
import model.Divisions;

public class DivisionsDAOImpl implements DivisionsDAO {

    @Override
    public ObservableList<Divisions> getAllDivisions() {
        return null;
    }

    @Override
    public Divisions getDivision(int divisionID) {
        return null;
    }

    @Override
    public ObservableList<Divisions> getDivisionsByCountry(int countryId) {
        return null;
    }

    @Override
    public int modifyDivisionName(String currentDivisionName, int countryId, String newDivisionName) {
        return 0;
    }

    @Override
    public int updateDivisionCountry(String divisionName, int currentCountryID, int newCountryID) {
        return 0;
    }

    @Override
    public int deleteDivision(int divisionID, String divisionName) {
        return 0;
    }

    @Override
    public int addDivision(String divisionName, int countryID) {
        return 0;
    }
}
