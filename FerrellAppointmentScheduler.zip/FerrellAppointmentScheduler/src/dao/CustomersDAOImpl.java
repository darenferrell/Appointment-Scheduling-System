package dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Countries;
import model.Customers;
import helper.JDBC.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static helper.JDBC.connection;

public class CustomersDAOImpl implements CustomersDAO {

    ObservableList<Customers> allCustomers = FXCollections.observableArrayList();

    public boolean customerLocated;

    @Override
    public Customers getAllCustomers(int customerID) {
        try {
            String sql = "SELECT * FROM Customers, first_level_divisions, countries WHERE " + "customers.Division+ID = first_level_divisions.Division_ID AND " + "first_level_divisions.Country_ID = countries.Country_ID";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();

            while (result.next()) {
                customerID = result.getInt("Customer_ID");
                int divisionID = result.getInt("Division_ID");
                int countryID = result.getInt("Country_ID");
                String customerName = result.getString("Customer_Name");
                String address = result.getString("Address");
                String postalCode = result.getString("postal_Code");
                String phone = result.getString("Phone");
                String countryName = result.getString("Country");
                String divisionName = result.getString("Division_Name");
                Customers cust = new Customers(customerID, divisionID, countryID, customerName, address, postalCode, phone, countryName, divisionName);
                allCustomers.add(cust);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        return (Customers) allCustomers;

    }

    @Override
    public ObservableList<Customers> getCustomersBasedOnCountry(int countryID) throws SQLException {
        ObservableList<Customers> customersBasedOnCountry = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM customers, first_level_divisions, countries WHERE\n" +
                    "customers.Division_ID = first_level_divisions.Division_ID AND \n" +
                    "first_level_divisions.Country_ID = countries.Country_ID AND countries.Country_ID=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, countryID);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int customerID = rs.getInt("Customer_ID");
                int divisionID = rs.getInt("Division_ID");
                countryID = rs.getInt("Country_ID");
                String customerName = rs.getString("Customer_Name");
                String address = rs.getString("Address");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("phone");
                String countryName = rs.getString("Country_Name");
                String divisionName = rs.getString("Division_Name");
                Customers cust = new Customers(customerID, divisionID, countryID, customerName, address, postalCode, phone, countryName, divisionName);
                customersBasedOnCountry.add(cust);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return customersBasedOnCountry;
    }


    @Override
    public int modifyCustomer(int customerID, String customerName, String address, String postalCode, String phone, int divisionID) {
        int affectedRows = 0;
        try {
            String sql = "UPDATE customers SET Customer_Name=?, Address=?, Postal_Code=?, Phone=?, Division_ID=? WHERE Customer_ID=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, customerName);
            ps.setString(2, address);
            ps.setString(3, postalCode);
            ps.setString(4, phone);
            ps.setInt(5, divisionID);
            ps.setInt(6, customerID);
            affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Customer modification was successful.");
            } else {
                System.out.println("Customer modification was not successful.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }


    @Override
    public int deleteCustomer(int customerID, String customerName) {
        int affectedRows = 0;
        try {
            String sql = "DELETE FROM customers WHERE customer=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, customerID);
            ps.setString(2, customerName);
            affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Customer record was deleted successfully.");
            } else {
                System.out.println("Customer record deletion was not successful.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }


    @Override
    public int addCustomer(String customerName, String address, String postalCode, String phone, int divisionID) {
        int affectedRows = 0;
        try {
            String sql = "INSERT INTO customers (customer_Name, address, postal_Code, phone, division_ID)" + " VALUES(?,?,?,?,?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, customerName);
            ps.setString(2, address);
            ps.setString(3, postalCode);
            ps.setString(4, phone);
            ps.setInt(5, divisionID);
            affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Customer record addition was successful.");
            } else {
                System.out.println("Customer record addition was not successful.");
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }


    @Override
    public Customers locateCustomerRecord(int customerID) {
        customerLocated = false;
        for (Customers cust : allCustomers) {
            if (cust.getCustomerID() == customerID) {
                customerLocated = true;
                return cust;
            }
        }
        return null;
    }
    
    @Override
    public ObservableList<Customers> locateCustomerRecord(String customerName) {
        ObservableList<Customers> filteredCustomers = FXCollections.observableArrayList();
        customerLocated = false;

        for (Customers cust : allCustomers) {
            if (cust.getCustomerName().toLowerCase().contains(customerName.toLowerCase())) {
                filteredCustomers.add(cust);
            }
        }
        if (filteredCustomers.isEmpty()) {
            return allCustomers;
        }
        customerLocated = true;
        return filteredCustomers;
    }
}

