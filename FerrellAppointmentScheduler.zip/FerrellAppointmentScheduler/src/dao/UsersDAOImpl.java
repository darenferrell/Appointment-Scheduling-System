package dao;

import helper.JDBC;
import javafx.collections.ObservableList;
import model.Users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsersDAOImpl implements UsersDAO {


    @Override
    public boolean loginQuery(String userName, String password) throws SQLException {
        Connection connection = JDBC.connection;
        String sqlStatement="select * FROM users WHERE User_Name  = ? and Password = ?";
        //  String sqlStatement="select FROM address";
        PreparedStatement ps = connection.prepareStatement(sqlStatement);
        ps.setString(1,userName);
        ps.setString(2, password);
        Users userResult;
        ResultSet result=ps.executeQuery();
        while(result.next()){
            return true;
        }
        return false;
    }

    @Override
    public ObservableList<Users> getAllUsers() {
        return null;
    }

    @Override
    public Users getUser(int userID) {
        return null;
    }

    @Override
    public int modifyUserPassword(String userName, String newPassword, String currentPassword) {
        return 0;
    }

    @Override
    public int modifyUserName(String currentUserName, String newUserName, String password) {
        return 0;
    }

    @Override
    public int deleteUser(int userID) {
        return 0;
    }

    @Override
    public int addUser(String userName, String password) {
        return 0;
    }

//    public static ObservableList<Users> getAllUsers() throws SQLException, Exception{
//        ObservableList<Users> allUsers= FXCollections.observableArrayList();
//        DBConnection.makeConnection();
//        String sqlStatement="select * from user";
//        Query.makeQuery(sqlStatement);
//        ResultSet result=Query.getResult();
//        while(result.next()){
//            int userID=result.getInt("userID");
//            String userNameG=result.getString("userName");
//            String password=result.getString("password");
//            int active=result.getInt("active");
//            if(active==1) act=true;
//            String createDate=result.getString("createDate");
//            String createdBy=result.getString("createdBy");
//            String lastUpdate=result.getString("lastUpdate");
//            String lastUpdateby=result.getString("lastUpdateBy");
//            Calendar createDateCalendar=stringToCalendar(createDate);
//            Calendar lastUpdateCalendar=stringToCalendar(lastUpdate);
//            //   s(int addressID, String address, String address2, int cityID, String postalCode, String phone, Calendar createDate, String createdBy, Calendar lastUpdate, String lastUpdateBy)
//            Users userResult= new Users(userID, userNameG, password, act, createDateCalendar, createdBy, lastUpdateCalendar, lastUpdateby);
//            allUsers.add(userResult);
//
//        }
//        DBConnection.closeConnection();
//        return allUsers;
//    }
    }


