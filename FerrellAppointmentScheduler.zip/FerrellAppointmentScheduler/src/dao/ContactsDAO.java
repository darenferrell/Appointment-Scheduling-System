package dao;
import javafx.collections.ObservableList;
import model.Contacts;

public interface ContactsDAO {

        public ObservableList<Contacts> getAllContacts();

        public Contacts getContact(int contactID);

        public int modifyContact(int contactID, String currentContactName, String newContactName);

        public int deleteContact(int contactID);

        public int addContact(String contactName);
    }

