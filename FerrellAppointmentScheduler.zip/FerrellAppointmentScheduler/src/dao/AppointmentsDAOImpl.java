package dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.Alert;
import model.Appointments;
import java.time.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import static helper.JDBC.connection;


    public class AppointmentsDAOImpl implements AppointmentsDAO {
        /**
         * This is the "all appointments" list.
         */
        ObservableList<Appointments> allAppointments = FXCollections.observableArrayList();
        /**
         * This is the appointment object used in the "look up appointment" method.
         */
        public boolean appointmentFound;

        /**
         * This is the "get All Appointments" method.
         * This method accesses the database and returns all appointments. Each appointment is then added to an observable list, "allAppointments".
         *
         * @return allAppointments list
         */
        @Override
        public ObservableList<Appointments> getAllAppointments() {
            try {
                String sql = "SELECT * FROM appointments";
                PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet result = ps.executeQuery();

                while (result.next()) {
                    int appointmentID = result.getInt("Appointment_ID");
                    int customerID = result.getInt("Customer_ID");
                    int userID = result.getInt("User_ID");
                    int contactID = result.getInt("Contact_ID");
                    String title = result.getString("Title");
                    String description = result.getString("Description");
                    String location = result.getString("Location");
                    String type = result.getString("Type");
                    LocalDateTime startDateTime = result.getTimestamp("Start").toLocalDateTime();
                    LocalDateTime endDateTime = result.getTimestamp("End").toLocalDateTime();
                    LocalDate startDate = startDateTime.toLocalDate();
                    LocalDate endDate = endDateTime.toLocalDate();
                    LocalTime startTime = startDateTime.toLocalTime();
                    LocalTime endTime = endDateTime.toLocalTime();
                    Appointments appointment = new Appointments(appointmentID, customerID, userID, contactID, title, description,
                            location, type, startDateTime, endDateTime, startDate, endDate, startTime, endTime);
                    allAppointments.add(appointment);
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return allAppointments;
        }

        /**
         * This is the "get appointment" method.
         * This method searches the database for a specific appointment based on its unique appointment ID.
         *
         * @param appointmentID the appointment in questions' specific ID
         * @return the appointment in questions' information
         * @return no result (null), if no appointment with the specific ID exists
         */
        @Override
        public Appointments getAppointment(int appointmentID) {
            try {
                String sql = "SELECT * FROM appointments WHERE Appointment_ID=?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, appointmentID);

                ResultSet result = ps.executeQuery();
                Appointments appointmentResult = null;
                if (result.next()) {
                    appointmentID = result.getInt("Appointment_ID");
                    int customerID = result.getInt("Customer_ID");
                    int userID = result.getInt("User_ID");
                    int contactID = result.getInt("Contact_ID");
                    String title = result.getString("Title");
                    String description = result.getString("Description");
                    String location = result.getString("Location");
                    String type = result.getString("Type");
                    LocalDateTime startDateTime = result.getTimestamp("Start").toLocalDateTime();
                    LocalDateTime endDateTime = result.getTimestamp("End").toLocalDateTime();
                    LocalDate startDate = startDateTime.toLocalDate();
                    LocalDate endDate = endDateTime.toLocalDate();
                    LocalTime startTime = startDateTime.toLocalTime();
                    LocalTime endTime = endDateTime.toLocalTime();
                    appointmentResult = new Appointments(appointmentID, customerID, userID, contactID, title, description,
                            location, type, startDateTime, endDateTime, startDate, endDate, startTime, endTime);
                }
                return appointmentResult;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return null;
        }

        /**
         * This is the "get appointment(s) by customer" method.
         * <p>This method accesses the database and filters a list of appointments, based on their related customer ID.
         * If an appointment is associated with the specific customer ID, it is added to a "customer appointments" list.</p>
         *
         * @param customerID the customer in questions' specific ID
         * @return customerAppts list
         */
        @Override
        public ObservableList<Appointments> getAppointmentBasedOnCustomer(int customerID) {
            ObservableList<Appointments> customerAppointments = FXCollections.observableArrayList();

            try {
                String sql = "SELECT * FROM appointments WHERE Customer_ID=?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, customerID);

                ResultSet result = ps.executeQuery();
                while (result.next()) {
                    int appointmentID = result.getInt("Appointment_ID");
                    customerID = result.getInt("Customer_ID");
                    int userID = result.getInt("User_ID");
                    int contactID = result.getInt("Contact_ID");
                    String title = result.getString("Title");
                    String description = result.getString("Description");
                    String location = result.getString("Location");
                    String type = result.getString("Type");
                    LocalDateTime startDateTime = result.getTimestamp("Start").toLocalDateTime();
                    LocalDateTime endDateTime = result.getTimestamp("End").toLocalDateTime();
                    LocalDate startDate = startDateTime.toLocalDate();
                    LocalDate endDate = endDateTime.toLocalDate();
                    LocalTime startTime = startDateTime.toLocalTime();
                    LocalTime endTime = endDateTime.toLocalTime();
                    Appointments appointment = new Appointments(appointmentID, customerID, userID, contactID, title, description,
                            location, type, startDateTime, endDateTime, startDate, endDate, startTime, endTime);
                    customerAppointments.add(appointment);
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return customerAppointments;
        }

        /**
         * This is the "get appointment(s) by contact" method.
         * <p>This method accesses the database and filters a list of appointments, based on their related contact ID.
         * If an appointment is associated with the specific contact ID, it is added to a "appointments by contact" list.</p>
         *
         * @param contactID the contact in questions' specific ID
         * @return apptsByContact list
         */
        @Override
        public ObservableList<Appointments> getAppointmentBasedOnContact(int contactID) {
            ObservableList<Appointments> appointmentsBasedOnContact = FXCollections.observableArrayList();

            try {
                String sql = "SELECT * FROM appointments WHERE Contact_ID=?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, contactID);

                ResultSet result = ps.executeQuery();
                while (result.next()) {
                    int appointmentID = result.getInt("Appointment_ID");
                    int customerID = result.getInt("Customer_ID");
                    int userID = result.getInt("User_ID");
                    contactID = result.getInt("Contact_ID");
                    String title = result.getString("Title");
                    String description = result.getString("Description");
                    String location = result.getString("Location");
                    String type = result.getString("Type");
                    LocalDateTime startDateTime = result.getTimestamp("Start").toLocalDateTime();
                    LocalDateTime endDateTime = result.getTimestamp("End").toLocalDateTime();
                    LocalDate startDate = startDateTime.toLocalDate();
                    LocalDate endDate = endDateTime.toLocalDate();
                    LocalTime startTime = startDateTime.toLocalTime();
                    LocalTime endTime = endDateTime.toLocalTime();
                    Appointments appointment = new Appointments(appointmentID, customerID, userID, contactID, title, description,
                            location, type, startDateTime, endDateTime, startDate, endDate, startTime, endTime);
                    appointmentsBasedOnContact.add(appointment);
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return appointmentsBasedOnContact;
        }

        /**
         * This is the "update appointment" method.
         * This method updates all values of a selected appointment based on its unique appointment ID.
         *
         * @param appointmentID the appointment in questions' unique appointment ID
         * @param customerID the appointment in questions' desired associated customer ID
         * @param userID the appointment in questions' desired associated user ID
         * @param contactID the appointment in questions' desired associated contact ID
         * @param title the appointment in questions' desired appointment title
         * @param description the appointment in questions' desired appointment description
         * @param location the appointment in questions' desired appointment location
         * @param type the appointment in questions' desired appointment type
         * @param startDateTime the appointment in questions' desired appointment start date and time
         * @param endDateTime the appointment in questions' desired appointment end date and time
         * @return the number of affected database rows
         */
        @Override
        public int modifyAppointment(int appointmentID, int customerID, int userID, int contactID, String title, String description,
                                     String location, String type, LocalDateTime startDateTime, LocalDateTime endDateTime) {
            int rowsAffected = 0;
            try {
                String sql = "UPDATE appointments SET Customer_ID=?, User_ID=?, Contact_ID=?, Title=?, Description=?, " +
                        "Location=?, Type=?, Start=?, End=? WHERE Appointment_ID=?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, customerID);
                ps.setInt(2, userID);
                ps.setInt(3, contactID);
                ps.setString(4, title);
                ps.setString(5, description);
                ps.setString(6, location);
                ps.setString(7, type);
                ps.setTimestamp(8, Timestamp.valueOf(startDateTime));
                ps.setTimestamp(9, Timestamp.valueOf(endDateTime));
                ps.setInt(10, appointmentID);
                rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Appointment UPDATE was successful!");
                } else {
                    System.out.println("Appointment UPDATE Failed!");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return rowsAffected;
        }

        /**
         * This is the "delete appointment" method.
         * <p>This method accesses the database and deletes an with a specific appointment ID, customer ID, and appointment type.
         * If an appointment was successfully (or unsuccessfully) deleted, an alert message populates with the result of the query. </p>
         *
         * @param appointmentID the appointment in questions' unique appointment ID
         * @param customerID the appointment in questions' associated customer ID
         * @param type the appointment in questions appointment type
         * @return the number of affected database rows
         */
        @Override
        public int deleteAppointment(int appointmentID, int customerID, String type) {
            int rowsAffected = 0;
            try {
                String sql = "DELETE FROM appointments WHERE Appointment_ID=? AND Customer_ID=? AND Type=?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, appointmentID);
                ps.setInt(2, customerID);
                ps.setString(3, type);
                rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Appointment [" + appointmentID + "] " + type + " was successfully deleted!");

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Appointment DELETE");
                    alert.setContentText("Appointment [" + appointmentID + "] " + type + " was successfully deleted!");
                    alert.showAndWait();
                } else {
                    System.out.println("Appointment DELETE failed!");

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Appointment DELETE");
                    alert.setContentText("Appointment [" + appointmentID + "] " + type + " failed to deleted!");
                    alert.showAndWait();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return rowsAffected;
        }

        /**
         * This is the "add appointment" method.
         * <p>This method accesses the database and adds an appointment to the system with the desired credentials (associated customer ID,
         * associated user ID, associated contact ID, appointment title, appointment description, appointment location, appointment type,
         * appointment desired start date and time, and desired appointment end date and time). </p>
         *
         * @param customerID associated customer ID
         * @param userID associated user ID
         * @param contactID associated contact ID
         * @param title appointment title
         * @param description appointment description
         * @param location appointment location
         * @param type appointment type
         * @param startDateTime appointment desired start date and time
         * @param endDateTime desired appointment end date and time
         * @return the number of affected database rows
         */
        @Override
        public int addAppointment(int customerID, int userID, int contactID, String title, String description, String location,
                                  String type, LocalDateTime startDateTime, LocalDateTime endDateTime) {
            int rowsAffected = 0;
            try {
                String sql = "INSERT INTO appointments (Customer_ID, User_ID, Contact_ID, Title, Description, Location, Type, " +
                        "Start, End) VALUES(?,?,?,?,?,?,?,?,?)";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, customerID);
                ps.setInt(2, userID);
                ps.setInt(3, contactID);
                ps.setString(4, title);
                ps.setString(5, description);
                ps.setString(6, location);
                ps.setString(7, type);
                ps.setTimestamp(8, Timestamp.valueOf(startDateTime));
                ps.setTimestamp(9, Timestamp.valueOf(endDateTime));
                rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Appointment INSERT was successful!");
                } else {
                    System.out.println("Appointment INSERT failed!");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return rowsAffected;
        }

        /**
         * This is the "look up appointments" method.
         * <p>This method searches the allAppointments list for a filtered list of appointments that are associated with a
         * specific (local) start date.</p>
         *
         * @param selectedDate (local) appointment start date in question
         * @return <p>the allAppointments list, if there are no matching appointments with the specified (local) start date;
         * Or the filteredAppts list of appointments associated with the (local) start date</p>
         */
        @Override
        public ObservableList<Appointments> lookUpAppointment(LocalDate selectedDate) {
            ObservableList<Appointments> filteredAppointments = FXCollections.observableArrayList();
            appointmentFound = false;

            for (Appointments appointment : allAppointments) {
                if (appointment.getStartDate().equals(selectedDate)) {
                    filteredAppointments.add(appointment);
                }
            }
            if (filteredAppointments.isEmpty()) {
                return allAppointments;
            }
            appointmentFound = true;
            return filteredAppointments;
        }



        /**
         * This is the "upcoming appointment alert" method.
         * <p>This method populates an alert message after the user initially logs in with a either: a list of upcoming appointments,
         * or a message stating the fact that there are no appointments scheduled to take place in the next 15 minutes. </p>
         *
         * <p>The method filters through all appointments stored in the database using the (local) date and time at login.
         * If an appointment meets the credentials it is then added to the "upcoming appointments" list, which is displayed in the alert box.
         * If the "upcoming appointments" list is empty, the other message populates (no upcoming appointments) instead.</p>
         *
         * @param ldt the operating systems local date and time at the users initial log in
         */
        @Override
        public void upcomingAppointmentAlert(LocalDateTime ldt) {
            try {
                ObservableList<Appointments> upcomingAppointments = FXCollections.observableArrayList();
                ObservableList<Appointments> allAppointments = FXCollections.observableArrayList();
                AppointmentsDAO aDAO = new AppointmentsDAOImpl();
                allAppointments = aDAO.getAllAppointments();

                ZoneId zoneId = ZoneId.systemDefault();
                ZonedDateTime loginZDT = ldt.atZone(zoneId);
                LocalDateTime apptStart = ldt.plusMinutes(15);

                for (Appointments appointment : allAppointments) {
                    ZonedDateTime zonedAppointment = ZonedDateTime.from(appointment.getStartDateAndTime().atZone(zoneId));
                    if (zonedAppointment.isAfter(loginZDT) && zonedAppointment.isBefore(apptStart.atZone(zoneId))) {
                        upcomingAppointments.add(appointment);
                        System.out.println("Upcoming appointment: " + appointment);
                    }
                }

                if (upcomingAppointments.size() == 0) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("No Upcoming Appointments");
                    alert.setContentText("There are no appointments scheduled to begin in the next 15 minutes!");
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Upcoming Appointments");
                    alert.setHeaderText("The following Appointments are scheduled to begin in the next 15 minutes:");
                    String alertText = "";

                    for (Appointments upAppt : upcomingAppointments) {
                        alertText = ("Appointment: [" + upAppt.getAppointmentID() + "] at " + upAppt.getStartTime() +
                                " (" + upAppt.getStartDate() + ")\n") + alertText;
                    }
                    alert.setContentText(alertText);
                    alert.showAndWait();
                }
            }catch (Exception e){
                System.out.println("Error: " + e.getMessage());
            }
        }

        /**
         * This is the "upcoming appointments for the next week" method.
         * <p>LAMBDA EXPRESSION: This method searches the all appointments list for a filtered list of appointments that will be occurring over
         * the next 7 days (including the date of the initial login). If an appointment in the database matched the credentials,
         * the lambda expression added the appointment to the filtered list, "filteredAppts."</p>
         *
         * <p>WHY I CHOSE TO USE A LAMBDA IN THIS SCENARIO: Using a lambda function required less code in this scenario compared to manually appending
         * each appointment to a filtered appointments list. </p>
         *
         * @param dateAtLogin the operating systems local date at the users initial log in
         * @return filteredAppts list
         */
        @Override
        public FilteredList<Appointments> upcomingAppointmentsBasedOnWeek(LocalDate dateAtLogin) {
            ObservableList<Appointments> allAppointments = FXCollections.observableArrayList();
            allAppointments = getAllAppointments();
            FilteredList<Appointments> filteredAppointments = new FilteredList<>(allAppointments);

            filteredAppointments.setPredicate(appointment -> {
                LocalDate appointmentDate = appointment.getStartDate();

                return ((appointmentDate.isEqual(dateAtLogin) || appointmentDate.isAfter(dateAtLogin)) &&
                        appointmentDate.isBefore(dateAtLogin.plusDays(7)));
            });
            return filteredAppointments;
        }




        /**
         * This is the "upcoming appointments for the rest of the month" method.
         * <p>LAMBDA EXPRESSION: This method searches the all appointments list for a filtered list of appointments that will be occurring
         * throughout the remaining of the current month (including the date of the initial login). If an appointment in the database matched the credentials,
         * the lambda expression added the appointment to the filtered list, "filteredAppts."</p>
         *
         * <p>WHY I CHOSE TO USE A LAMBDA IN THIS SCENARIO: Using a lambda function required less code in this scenario compared to manually appending
         * each appointment to a filtered appointments list. </p>
         *
         * @param dateAtLogin the operating systems local date at the users initial log in
         * @return filteredAppts list
         */
        @Override
        public FilteredList<Appointments> upcomingAppointmentsBasedOnMonth(LocalDate dateAtLogin) {
            ObservableList<Appointments> allAppointments = FXCollections.observableArrayList();
            allAppointments = getAllAppointments();
            FilteredList<Appointments> filteredAppts = new FilteredList<>(allAppointments);

            filteredAppts.setPredicate(appointment -> {
                LocalDate appointmentDate = appointment.getStartDate();

                return (appointmentDate.isEqual(dateAtLogin) || appointmentDate.isAfter(dateAtLogin)) &&
                        appointmentDate.getMonth().equals(dateAtLogin.getMonth());
            });
            return filteredAppts;
        }

        /**
         * This is the "check appointment start time" method.
         * <p>This method checks a desired appointment start time to see if the selected time is within "business hours" (0800 - 2200 EST).
         * The method takes the desired start time and converts it from local time to EST and checks to see if it is within business hours.
         * The method also checks to see if the time occurs before "closing" time. If the time is within business hours, and meets the other credentials,
         * the method returns true.</p>
         * @param apptStartTime the desired appointment start time that is in question
         * @return true, if the desired time meets the credentials
         */
        @Override
        public boolean checkAppointmentStartTime(LocalDateTime apptStartTime) {
            ZonedDateTime apptZone = apptStartTime.atZone(ZoneId.systemDefault());
            apptZone = apptZone.withZoneSameInstant(ZoneId.of("US/Eastern"));
            apptStartTime = apptZone.toLocalDateTime();

            LocalTime businessOpen = LocalTime.of(8, 0);
            LocalTime businessClose = LocalTime.of(22, 0);
            return ((apptStartTime.toLocalTime().isAfter(businessOpen) || apptStartTime.toLocalTime().equals(businessOpen)) &&
                    (apptStartTime.toLocalTime().isBefore(businessClose)));
        }


        @Override
        public boolean checkAppointmentEndTime(LocalDateTime appointmentEndTime) {
            ZonedDateTime apptZone = appointmentEndTime.atZone(ZoneId.systemDefault());
            apptZone = apptZone.withZoneSameInstant(ZoneId.of("US/Eastern"));
            appointmentEndTime = apptZone.toLocalDateTime();

            LocalTime businessOpen = LocalTime.of(8, 0);
            LocalTime businessClose = LocalTime.of(22, 0);
            return ((appointmentEndTime.toLocalTime().isAfter(businessOpen)) &&
                    (appointmentEndTime.toLocalTime().isBefore(businessClose) || appointmentEndTime.toLocalTime().equals(businessClose)));    //can end at close!
        }

        @Override
        public boolean checkNewAppointmentForOverlap(int customerID, LocalDate selectedStartDate, LocalDate selectedEndDate, LocalTime selectedStartTime,
                                              LocalTime selectedEndTime) {
            AppointmentsDAO appointmentDAO = new AppointmentsDAOImpl();
            ObservableList<Appointments> customerAppts = appointmentDAO.getAppointmentBasedOnCustomer(customerID);
            boolean overlap = false;

            for (Appointments appointment : customerAppts) {
                //start or end on same day
                if ((appointment.getStartDate().isEqual(selectedStartDate)) || (appointment.getEndDate().isEqual(selectedEndDate))) {
                    //start at the same time
                    if (appointment.getStartTime().equals(selectedStartTime)) {
                        overlap = true;
                        break;
                        //old appt starts after new appt begins & old appt starts before old ends
                    } else if(appointment.getStartTime().isAfter(selectedStartTime) && appointment.getStartTime().isBefore(selectedEndTime)) {
                        overlap = true;
                        break;
                        //new appt starts before old starts & new appt ends after old appt starts
                    }else if(selectedStartTime.isBefore(appointment.getStartTime()) && (selectedEndTime.isAfter(appointment.getStartTime()))) {
                        overlap = true;
                        break;
                    }
                }
            }
            return overlap;
        }


        @Override
        public boolean checkModifiedAppointmentForOverlap(int customerID, LocalDate selectedStartDate, LocalDate selectedEndDate, LocalTime selectedStartTime,
                                                  LocalTime selectedEndTime, int appointmentID) {
            AppointmentsDAO aDao = new AppointmentsDAOImpl();
            ObservableList<Appointments> customerAppts = aDao.getAppointmentBasedOnCustomer(customerID);
            boolean overlap = false;

            for(Appointments appointment : customerAppts) {
                //check to see if appointment times changed
                if((appointment.getAppointmentID() == appointmentID) && (selectedStartTime.equals(appointment.getStartTime()) && (selectedEndTime.equals(appointment.getEndTime())))) {
                    break;
                    //if appointment time DID change, go through overlap check
                }else {
                    checkNewAppointmentForOverlap(customerID, selectedStartDate, selectedEndDate, selectedStartTime, selectedEndTime);
                }
            }
            return overlap;
        }
    }
