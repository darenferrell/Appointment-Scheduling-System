package dao;

import javafx.collections.ObservableList;
import model.Appointments;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public interface AppointmentsDAO {

    public ObservableList<Appointments> getAllAppointments();


    public Appointments getAppointment(int appointmentID);


    public ObservableList<Appointments> getAppointmentBasedOnCustomer(int customerID);


    public ObservableList<Appointments> getAppointmentBasedOnContact(int contactID);


    public int modifyAppointment(int appointmentID, int customerID, int userID, int contactID, String title, String description,
                                 String location, String type, LocalDateTime startDateTime, LocalDateTime endDateTime);

    public int deleteAppointment(int appointmentID, int customerID, String type);

    public int addAppointment(int customerID, int userID, int contactID, String title, String description,
                              String location, String type, LocalDateTime startDateTime, LocalDateTime endDateTime);


    public ObservableList<Appointments> lookUpAppointment(LocalDate date);

    public void upcomingAppointmentAlert(LocalDateTime loginLDT);


    public ObservableList<Appointments> upcomingAppointmentsBasedOnWeek(LocalDate loginLD);

    public ObservableList<Appointments> upcomingAppointmentsBasedOnMonth(LocalDate loginLD);


    public boolean checkAppointmentStartTime(LocalDateTime appointmentStartTime);


    public boolean checkAppointmentEndTime(LocalDateTime appointmentEndTime);

    public boolean checkNewAppointmentForOverlap(int customerID, LocalDate selectedStartDate, LocalDate selectedEndDate, LocalTime selectedStartTime,
                                          LocalTime selectedEndTime);

    public boolean checkModifiedAppointmentForOverlap(int customerID, LocalDate selectedStartDate, LocalDate selectedEndDate, LocalTime selectedStartTime,
                                              LocalTime selectedEndTime, int appointmentID);

}
