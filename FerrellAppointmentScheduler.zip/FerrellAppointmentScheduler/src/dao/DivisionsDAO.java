package dao;

import javafx.collections.ObservableList;
import model.Divisions;

public interface DivisionsDAO {

        public ObservableList<Divisions> getAllDivisions();

        public Divisions getDivision(int divisionID);

        public ObservableList<Divisions> getDivisionsBasedOnCountry(int countryID);

        public int modifyDivisionName(String currentDivisionName, int countryId, String newDivisionName);

        public int updateDivisionCountry(String divisionName, int currentCountryID, int newCountryID);


        public int deleteDivision(int divisionID, String divisionName);


        public int addDivision(String divisionName, int countryID);
    }

