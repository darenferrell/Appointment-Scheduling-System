package dao;

import javafx.collections.ObservableList;
import model.Customers;

import java.sql.SQLException;

public interface CustomersDAO {



    public Customers getAllCustomers(int customerID);

    public ObservableList<Customers> getCustomersBasedOnCountry(int countryID) throws SQLException;

    public int modifyCustomer(int customerID, String customerName, String address, String postalCode, String phone, int divisionID);

    public int deleteCustomer(int customerID, String customerName);

    public int addCustomer(String customerName, String address, String postalCode, String phone, int divisionID);

    public Customers locateCustomerRecord(int customerId);

    public ObservableList<Customers> locateCustomerRecord(String customerName);

    }

