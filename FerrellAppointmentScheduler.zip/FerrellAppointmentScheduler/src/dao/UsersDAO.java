package dao;

import javafx.collections.ObservableList;
import model.Users;

import java.sql.SQLException;

public interface UsersDAO {

    boolean loginQuery(String userName, String password) throws SQLException;

    public ObservableList<Users> getAllUsers();


    public Users getUser(int userID);


    public int modifyUserPassword(String userName, String newPassword, String currentPassword);


    public int modifyUserName(String currentUserName, String newUserName, String password);


    public int deleteUser(int userID);


    public int addUser(String userName, String password);
}


