package dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contacts;
import model.Countries;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static helper.JDBC.connection;

public class CountriesDAOImpl implements CountriesDAO {

    ObservableList<Countries> allCountries = FXCollections.observableArrayList();

    @Override
    public ObservableList<Countries> getAllCountries() {

            try {
                String sql = "SELECT * FROM countries";
                PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet result = ps.executeQuery();

                while (result.next()) {
                    int countryID = result.getInt("Country ID");
                    String countryName = result.getString("Country Name");

                    Countries country = new Countries (countryName, countryID);
                    allCountries.add(country);
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            return allCountries;
        }



    @Override
    public Countries getCountry(int countryID) {
            try {
                String sql = "SELECT * FROM countries where country_ID = ?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setInt(1, countryID);
                ResultSet result = ps.executeQuery();
                Countries countryResult = null;

                if (result.next()) {
                    countryID = result.getInt("Country_ID");
                    String contactName = result.getString("Country_Name");
                    String countryName = null;
                    countryResult = new Countries(countryName, countryID);
                }
                return countryResult;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            return null;
        }



    @Override
    public int modifyCountry(int countryID, String currentCountryName, String newCountryName) {
            int affectedRows = 0;
            try {
                String sql = "UPDATE contacts set Contact_Name=? WHERE Contact_Name=? AND Contact_ID=?";
                PreparedStatement ps = connection.prepareStatement(sql);
                ps.setString(1, newCountryName);
                ps.setString(2, currentCountryName);
                ps.setInt(3, countryID);
                affectedRows = ps.executeUpdate();

                if (affectedRows > 0) {
                    System.out.println(currentCountryName + "modification was successful!");
                    System.out.println("New Contact name: " + newCountryName);

                } else {
                    System.out.println(currentCountryName + " name modification has failed.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            return affectedRows;
        }



    @Override
    public int deleteCountry(int countryID, String countryName) {
        int affectedRows = 0;
        helper.JDBC.openConnection();
        DivisionsDAO dDAO = new DivisionsDAOImpl();
        try {
            String sql = "DELETE FROM countries WHERE Country_ID=? AND CountryName=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, countryID);
            ps.setString(2, countryName);
            affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Country " + countryName + " " + countryID + "was successfully deleted.");

            } else {
                System.out.println("Country " + countryName + " " + countryID + "has not been deleted.");
            }
            if (!dDAO.getDivisionsBasedOnCountry(countryID).isEmpty()) {
                System.out.println(countryName + " was not deleted.");
                System.out.println(countryName + " is associated with additional divisions. Please be sure to delete any remaining divisions before attempting to delete country.");
            }
        }
            catch(Exception e){
                System.out.println("Error: " + e.getMessage());
            }
            return affectedRows;
        }


    @Override
    public int addCountry(String countryName) {
        int affectedRows = 0;
        try {
            String sql = "INSERT INTO countries (Country) VALUES(?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, countryName);
            affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Country addition was successful.");
            }
            else {
                System.out.println("Country addition was unsuccessful.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return affectedRows;
    }
}
