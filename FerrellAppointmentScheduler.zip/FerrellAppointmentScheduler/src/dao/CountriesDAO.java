package dao;

import javafx.collections.ObservableList;
import model.Countries;

public interface CountriesDAO {

        public ObservableList<Countries> getAllCountries();


        public Countries getCountry(int countryID);


        public int modifyCountry(int countryID, String currentCountryName, String newCountryName);


        public int deleteCountry(int countryID, String countryName);


        public int addCountry(String countryName);
    }

